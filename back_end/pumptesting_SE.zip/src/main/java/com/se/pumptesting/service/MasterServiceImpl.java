package com.se.pumptesting.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.se.pumptesting.utils.ApplicationResponse;
import com.se.pumptesting.utils.RequestWrapper;

@Service
public class MasterServiceImpl implements MasterService {

	@Override
	public ApplicationResponse addRecord(String requestPayload) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ApplicationResponse updateRecord(String bodyPaylod) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ApplicationResponse deleteRecords(List<Integer> ids) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ApplicationResponse getRecords() {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ApplicationResponse getRecordsWithPagination(RequestWrapper requestWrapper) {

		// TODO Auto-generated method stub
		return null;
	}

}
