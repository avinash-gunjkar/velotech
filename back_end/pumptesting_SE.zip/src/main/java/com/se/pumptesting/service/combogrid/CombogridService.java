
package com.se.pumptesting.service.combogrid;

import com.se.pumptesting.utils.ApplicationResponse;
import com.se.pumptesting.utils.RequestWrapper;

public interface CombogridService {

	ApplicationResponse getMotorMasters(RequestWrapper requestWrapper);
}
