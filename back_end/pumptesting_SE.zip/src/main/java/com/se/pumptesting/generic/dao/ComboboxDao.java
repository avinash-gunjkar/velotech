
package com.se.pumptesting.generic.dao;

import java.util.List;

import com.se.pumptesting.models.Tbl00ModelMaster;

public interface ComboboxDao {

	List<Tbl00ModelMaster> getModelMasters();

}
