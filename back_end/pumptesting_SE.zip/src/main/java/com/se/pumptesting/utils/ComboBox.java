/**
 * 
 */
package com.se.pumptesting.utils;

/**
 * @author SHARAD
 *
 */
public class ComboBox {

	private Object label;

	private Object value;

	public Object getLabel() {

		return label;
	}

	public void setLabel(Object label) {

		this.label = label;
	}

	public Object getValue() {

		return value;
	}

	public void setValue(Object value) {

		this.value = value;
	}

}
