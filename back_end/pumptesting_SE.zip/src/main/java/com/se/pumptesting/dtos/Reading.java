
package com.se.pumptesting.dtos;

public class Reading {

	private String parameter;

	private Object value;

	public String getParameter() {

		return parameter;
	}

	public void setParameter(String parameter) {

		this.parameter = parameter;
	}

	public Object getValue() {

		return value;
	}

	public void setValue(Object value) {

		this.value = value;
	}

}
