
package com.se.pumptesting.reports.dto;

public class ReportDto {

	private String reportName;

	private Integer id;

	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {

		this.id = id;
	}

	public String getReportName() {

		return reportName;
	}

	public void setReportName(String reportName) {

		this.reportName = reportName;
	}
}
